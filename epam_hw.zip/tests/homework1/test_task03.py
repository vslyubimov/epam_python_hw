from homework1.task03 import find_maximum_and_minimum


def test_task_03():
    assert find_maximum_and_minimum("some_file.txt")
